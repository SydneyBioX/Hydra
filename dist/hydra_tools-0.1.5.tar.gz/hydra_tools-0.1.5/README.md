# Interpretable deep generative ensemble learning for single-cell omics with Hydra

</br>

<img width="842" height="1005" alt="Hydra" src="https://github.com/user-attachments/assets/0ac47760-9cbb-4420-a4fb-74d74b777ed7" />
















